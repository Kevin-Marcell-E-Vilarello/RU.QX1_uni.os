import numpy as np
import csv
import os
import datetime

# === CONFIGURACIÓN V01 (Kevin Marcell) ===
THREAD_COUNT = 256
DECAY_CONSTANT = 100
EJE_TORQUE_V01 = 18.0000  # Nueva barrera de Sinceridad
BASE_FREQ = 0.5
FREQ_RANGE = (0.45, 0.55)
PHASE_RANGE = (0, 2 * np.pi)
TIME_STEPS = 100

# === RUTAS Q-LAB ===
base_lab_path = os.path.expanduser("~/QLAB_FORK_V01")
timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
test_folder = os.path.join(base_lab_path, "research", f"Test_{timestamp}")
os.makedirs(test_folder, exist_ok=True)

CSV_FILENAME = os.path.join(test_folder, "unios_v01_results.csv")
LOG_FILENAME = os.path.join(base_lab_path, "logs", "unios_ledger_v01.log")

# === TIEMPO Y ENVELOPE (S56.7) ===
t = np.linspace(0, 1, TIME_STEPS)
# Onda de referencia base Z
Z = np.sin(2 * np.pi * BASE_FREQ * t) * np.exp(-t * TIME_STEPS / DECAY_CONSTANT)

# === SIMULACIÓN DE RESONANCIA ===
results = []
accepted_v01 = 0

for i in range(THREAD_COUNT):
    f = np.random.uniform(*FREQ_RANGE)
    phi = np.random.uniform(*PHASE_RANGE)
    # Generación de onda ψ
    psi = np.sin(2 * np.pi * f * t + phi) * np.exp(-t * TIME_STEPS / DECAY_CONSTANT)
    
    # Cálculo de Delta (Desviación Integral)
    delta_raw = np.abs(np.trapz(psi - Z, t))
    
    # Métrica de Sinceridad V01: Inversión de Torque
    # Escalamos la delta para verificar si alcanza la resonancia del Eje 18
    sincery_score = delta_raw * 100 
    is_sincere = sincery_score >= EJE_TORQUE_V01

    if is_sincere:
        accepted_v01 += 1

    results.append({
        "Thread": i + 1,
        "Frequency": f,
        "Phase": phi,
        "Delta": delta_raw,
        "Sincerity_Score": sincery_score,
        "Accepted_V01": is_sincere
    })

# === EXPORTACIÓN DE RESULTADOS ===
with open(CSV_FILENAME, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["Thread", "Frequency", "Phase", "Delta", "Sincerity_Score", "Accepted_V01"])
    writer.writeheader()
    for row in results:
        writer.writerow(row)

# === ACTUALIZACIÓN DEL LEDGER DE SINCERIDAD ===
with open(LOG_FILENAME, "a") as l:
    l.write(f"[{timestamp}] V01_RESONANCE_RUN | Total: {THREAD_COUNT} | Sincere: {accepted_v01} | Torque: {EJE_TORQUE_V01}\n")

print(f"--- QAPPCU V01 COMPLETA ---")
print(f"Hilos con Sinceridad V01: {accepted_v01} / {THREAD_COUNT}")
print(f"Resultados en: {test_folder}")
