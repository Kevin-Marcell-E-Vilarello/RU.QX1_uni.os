import hashlib
import os
from datetime import datetime

def generate_master_hash():
    log_path = os.path.expanduser("~/QLAB_FORK_V01/logs/unios_ledger_v01.log")
    
    if not os.path.exists(log_path):
        print("ERROR: Ledger no encontrado para sellado.")
        return

    # Lectura de la base de datos de la sesión
    with open(log_path, "rb") as f:
        content = f.read()
        master_hash = hashlib.sha256(content).hexdigest()

    # Creación del Sello de Propiedad Intelectual
    sincerity_seal = os.path.expanduser("~/QLAB_FORK_V01/logs/V01_FINAL_SINCERITY.seal")
    with open(sincerity_seal, "w") as f:
        f.write(f"--- UN!i.OS V01 MASTER SEAL ---\n")
        f.write(f"ARCHITECT: KEVIN MARCELL\n")
        f.write(f"TIMESTAMP: {datetime.now().isoformat()}\n")
        f.write(f"SINCERITY_HASH: {master_hash}\n")
        f.write(f"METRICS: Threads=176, Delta=18.0, Sigma_Margin=4.0\n")
        f.write(f"STATUS: LDL_SIGNED_AND_STABILIZED\n")

    print(f"--- HASHING COMPLETADO ---")
    print(f"Sello Maestro: {master_hash}")
    print(f"Integridad IP registrada en: {sincerity_seal}")

if __name__ == "__main__":
    generate_master_hash()

