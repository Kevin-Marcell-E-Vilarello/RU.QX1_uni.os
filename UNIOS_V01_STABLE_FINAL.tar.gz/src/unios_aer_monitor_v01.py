import os
import math

# === PARÁMETROS AER V01 (Kevin Marcell) ===
# Basado en el Principio de No Desestabilización
MU_ACTUAL = 1.0  
RHO_CRIT = 0.85  
TLH = -0.1       

def calcular_aer_sinceridad(freq, delta_raw):
    # E_info = (1/mu) * (rho * f - rho_crit)
    e_info = (1 / MU_ACTUAL) * (delta_raw * freq - RHO_CRIT)
    
    if e_info >= 0:
        status = "CRITICAL COLLAPSE"
    elif e_info >= TLH:
        status = "NEAR FAILURE ALERT (TURBULENT)"
    else:
        status = "LAMINAR (SAFE)"
        
    return e_info, status

def ejecutar_monitoreo():
    log_path = os.path.expanduser("~/QLAB_FORK_V01/logs/unios_ledger_v01.log")
    
    # Evaluación de prueba para validación de buffer
    e_info, status = calcular_aer_sinceridad(0.5, 176/256)
    
    entry = (f"AER_LOG | E_info: {e_info:.4f} | Status: {status} | "
             f"Mu: {MU_ACTUAL}\n")
    
    with open(log_path, "a") as f:
        f.write(entry)
    
    print(f"--- MONITOR AER V01: REGISTRADO ---")
    print(f"Estado: {status}")

if __name__ == "__main__":
    ejecutar_monitoreo()
