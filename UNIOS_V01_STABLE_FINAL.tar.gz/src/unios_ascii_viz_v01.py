import numpy as np

# Datos de la sesión actual
HILOS = 176
TORQUE = 18.0
SIGMA = 22.0

def generar_viz():
    print(f"\n--- HUELLA DE RESONANCIA OKTOPLUS (V01) ---")
    print(f"Arquitecto: Kev | Sinceridad: {HILOS} hilos\n")
    
    # Mapa de caracteres según intensidad de fase
    chars = [" ", ".", ":", "-", "=", "+", "*", "#", "%", "@"]
    
    for i in range(8):
        row = ""
        for j in range(8):
            # Cálculo de fase basado en tu Eje 18
            val = (np.sin((TORQUE * np.pi / SIGMA) * (i + j)) + 1) / 2
            idx = int(val * (len(chars) - 1))
            row += chars[idx] + "  "
        print(f"  {row}")
    
    print(f"\nEstado: LAMINAR | Delta < Sigma: {TORQUE < SIGMA}")

if __name__ == "__main__":
    generar_viz()
