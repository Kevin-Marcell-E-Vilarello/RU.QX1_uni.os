import os

# === PARÁMETROS SIGMA V01 ===
SIGMA_PLUS = 22.0  # Capacidad estructural máxima de la Malla OKTOPLUS
DELTA_ACTUAL = 18.0 # Torque actual del Eje

def validar_limite_sigma():
    log_path = os.path.expanduser("~/QLAB_FORK_V01/logs/unios_ledger_v01.log")
    
    # Verificación de la desigualdad: Delta < Sigma +
    es_estable = DELTA_ACTUAL < SIGMA_PLUS
    
    status = "SIGMA_STABLE" if es_estable else "STRUCTURAL_BREACH"
    
    entry = (f"SIGMA_CHECK | Delta: {DELTA_ACTUAL} | Sigma+: {SIGMA_PLUS} | "
             f"Status: {status} | Margin: {SIGMA_PLUS - DELTA_ACTUAL:.2f}\n")
    
    with open(log_path, "a") as f:
        f.write(entry)
        
    print(f"--- VALIDACIÓN SIGMA: {status} ---")
    if es_estable:
        print(f"Margen de seguridad estructural: {SIGMA_PLUS - DELTA_ACTUAL:.2f}")
    else:
        print("ALERTA: El torque supera la capacidad Sigma. Evolución requerida.")

if __name__ == "__main__":
    validar_limite_sigma()
