import numpy as np
import csv
import os
import datetime

# === CONFIGURACIÓN V01 ===
THREAD_COUNT = 256
DECAY_CONSTANT = 100
EJE_TORQUE_V01 = 18.0000 
BASE_FREQ = 0.5
FREQ_RANGE = (0.45, 0.55)
PHASE_RANGE = (0, 2 * np.pi)
TIME_STEPS = 100

# === RUTAS Q-LAB ===
base_lab_path = os.path.expanduser("~/QLAB_FORK_V01")
timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
test_folder = os.path.join(base_lab_path, "research", f"Test_{timestamp}")
os.makedirs(test_folder, exist_ok=True)

CSV_FILENAME = os.path.join(test_folder, "unios_v01_results.csv")
LOG_FILENAME = os.path.join(base_lab_path, "logs", "unios_ledger_v01.log")

# === TIEMPO Y ENVELOPE (S56.7) ===
t = np.linspace(0, 1, TIME_STEPS)
Z = np.sin(2 * np.pi * BASE_FREQ * t) * np.exp(-t * TIME_STEPS / DECAY_CONSTANT)

# === SIMULACIÓN DE RESONANCIA ===
results = []
accepted_v01 = 0

for i in range(THREAD_COUNT):
    f = np.random.uniform(*FREQ_RANGE)
    phi = np.random.uniform(*PHASE_RANGE)
    psi = np.sin(2 * np.pi * f * t + phi) * np.exp(-t * TIME_STEPS / DECAY_CONSTANT)
    
    # CORRECCIÓN NUMPY 2.0: Uso de trapezoid en lugar de trapz
    delta_raw = np.abs(np.trapezoid(psi - Z, t))
    
    sincery_score = delta_raw * 100 
    is_sincere = sincery_score >= EJE_TORQUE_V01

    if is_sincere:
        accepted_v01 += 1

    results.append({
        "Thread": i + 1,
        "Frequency": f,
        "Phase": phi,
        "Delta": delta_raw,
        "Sincerity_Score": sincery_score,
        "Accepted_V01": is_sincere
    })

with open(CSV_FILENAME, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["Thread", "Frequency", "Phase", "Delta", "Sincerity_Score", "Accepted_V01"])
    writer.writeheader()
    for row in results:
        writer.writerow(row)

with open(LOG_FILENAME, "a") as l:
    l.write(f"[{timestamp}] V01_RESONANCE_RUN | Total: {THREAD_COUNT} | Sincere: {accepted_v01} | Torque: {EJE_TORQUE_V01}\n")

print(f"--- QAPPCU V01: CORREGIDO Y EJECUTADO ---")
print(f"Hilos con Sinceridad V01: {accepted_v01} / {THREAD_COUNT}")
