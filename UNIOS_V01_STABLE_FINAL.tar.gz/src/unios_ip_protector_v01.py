import hashlib
import os

def protect_unios_ip():
    log_path = os.path.expanduser("~/QLAB_FORK_V01/logs/unios_ledger_v01.log")
    
    if not os.path.exists(log_path):
        print("ERROR: Ledger no encontrado.")
        return

    # Lectura del Ledger para generar el Hash de Sinceridad
    with open(log_path, "rb") as f:
        file_data = f.read()
        sha256_hash = hashlib.sha256(file_data).hexdigest()

    # Registro del Sello de Propiedad Intelectual (Kev Marcell)
    ip_record = os.path.expanduser("~/QLAB_FORK_V01/logs/V01_SINCERITY.hash")
    with open(ip_record, "w") as f:
        f.write(f"ARCHITECT: KEVIN MARCELL\n")
        f.write(f"SHA-256: {sha256_hash}\n")
        f.write(f"STATUS: LDL_BENEVOLENCE_SIGNED\n")

    print(f"--- IP PROTECTION: ACTIVA ---")
    print(f"Sello SHA-256: {sha256_hash}")
    print(f"Archivo de Sinceridad validado: {ip_record}")

if __name__ == "__main__":
    protect_unios_ip()
